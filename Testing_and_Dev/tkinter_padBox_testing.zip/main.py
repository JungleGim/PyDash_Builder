
import tkinter as tk
import re

lbl_font = ("Arial", 12)

test_text = 'Ting'
#---test font 1
'''test_font = ("Sui Generis", 50)
test_NWjustx0=20
test_NWjusty0=60
test_manual_shrink_y0 = 0
test_manual_shrink_y1 = 10'''
#---test font 2
#test_font = ("Arial", 20)
#---test font 2
test_font = ("Lemon", 50)
test_NWjustx0=20
test_NWjusty0=60
test_manual_shrink_y0 = 0
test_manual_shrink_y1 = -10

frm_x = 200
frm_y = 200

pad_margin = 0
default_pad_clr = 'grey'
replace_pattern = r'\{.*?\}'

ppi_pt_conv = 96/72     #point conversion based on 96ppi and 1in = 72pt

class wndw_Main(tk.Tk):
    """Primary tkinter window class"""
    def __init__(self):
        tk.Tk.__init__(self)
    
        self.make_test_eles()    #build test elements

    def make_test_eles(self):
        #----display framework
        #-display frames
        self.frm_info = tk.Frame(self, height=100)              #frame to show generation conditions
        self.frm_info.grid(row=2, column=0)
        self.frm_visual = tk.Frame(self, height=100)            #frame to show visual output
        self.frm_visual.grid(row=2, column=0)
        #-generation information
        gen_info = 'Pad Size: '+str(pad_margin)+' | Font: '+str(test_font)
        pad_size_lbl = tk.Label(self, text=gen_info, font=lbl_font)
        pad_size_lbl.grid(row=0, column=0, sticky=tk.W, padx=20, pady=20)

        #----test1
        """like existing pydash - anchor tk.NW + BBOX"""
        #-make container and canvas
        test1_lbl = tk.Label(self.frm_visual, text="anchor=tk.NW\npad=BBOX\nCanvObj=Text", font=lbl_font)
        test1_lbl.grid(row=0, column=0)
        test1_canv = tk.Canvas(master=self.frm_visual, width=frm_x, height=frm_y, highlightthickness=3, highlightbackground='black')
        test1_canv.grid(row=1, column=0, padx=10, pady=10)
        #-place canvas object
        test1_txt = test1_canv.create_text(test_NWjustx0, test_NWjusty0, text=test_text, font=test_font, anchor=tk.NW)
        #-make surrounding pad
        test1_pad = self.make_pad_BBOX(test1_canv, test1_txt)
       
        #----test2
        """anchor tk.NW + ppi/pt conversion"""
        #-make container and canvas
        test2_lbl = tk.Label(self.frm_visual, text="anchor=tk.NW\npad=ppi/pt\nCanvObj=Text", font=lbl_font)
        test2_lbl.grid(row=0, column=1)
        test2_canv = tk.Canvas(master=self.frm_visual, width=frm_x, height=frm_y, highlightthickness=3, highlightbackground='black')
        test2_canv.grid(row=1, column=1, padx=10, pady=10)
        #-place canvas object
        test2_txt = test2_canv.create_text(test_NWjustx0, test_NWjusty0, text=test_text, font=test_font, anchor=tk.NW)
        #-make surrounding pad
        test2_pad = self.make_pad_ptCONV(test2_canv, test2_txt, tk.NW)

        #----test3
        """anchor tk.CENTER + BBOX"""
        #-make container and canvas
        test3_lbl = tk.Label(self.frm_visual, text="anchor=tk.CENTER\npad=BBOX\nCanvObj=Text", font=lbl_font)
        test3_lbl.grid(row=0, column=2)
        test3_canv = tk.Canvas(master=self.frm_visual, width=frm_x, height=frm_y, highlightthickness=3, highlightbackground='black')
        test3_canv.grid(row=1, column=2, padx=10, pady=10)
        #-place canvas object
        test3_txt = test3_canv.create_text(frm_x/2, frm_y/2, text=test_text, font=test_font, anchor=tk.CENTER)
        test3_pad = self.make_pad_BBOX(test3_canv, test3_txt)

        #----test4
        """anchor tk.CENTER + ppi/pt conversion"""
        #-make container and canvas
        test4_lbl = tk.Label(self.frm_visual, text="anchor=tk.CENTER\npad=ppi/pt\nCanvObj=Text", font=lbl_font)
        test4_lbl.grid(row=0, column=3)
        test4_canv = tk.Canvas(master=self.frm_visual, width=frm_x, height=frm_y, highlightthickness=3, highlightbackground='black')
        test4_canv.grid(row=1, column=3, padx=10, pady=10)
        #-place canvas object
        test4_txt = test4_canv.create_text(frm_x/2, frm_y/2, text=test_text, font=test_font, anchor=tk.CENTER)
        test4_pad = self.make_pad_ptCONV(test4_canv, test4_txt, tk.CENTER)

        #----test5
        """anchor tk.NW + Overlapping"""
        #-make container and canvas
        test5_lbl = tk.Label(self.frm_visual, text="anchor=tk.NW\npad=OVRLP\nCanvObj=Text", font=lbl_font)
        test5_lbl.grid(row=0, column=4)
        test5_canv = tk.Canvas(master=self.frm_visual, width=frm_x, height=frm_y, highlightthickness=3, highlightbackground='black')
        test5_canv.grid(row=1, column=4, padx=10, pady=10)
        #-place canvas object
        test5_txt = test5_canv.create_text(test_NWjustx0, test_NWjusty0, text=test_text, font=test_font, anchor=tk.NW)
        #-make surrounding pad
        test5_pad = self.make_pad_OVERLAPPING(test5_canv, test5_txt)

        #----test6
        """add text label using window"""
        #explore if a text label with a border width is tighter to the text
        #-make container and canvas
        test6_lbl = tk.Label(self.frm_visual, text="anchor=tk.CENTER\npad=label borderwidth\nCanvObj=Window+label", font=lbl_font)
        test6_lbl.grid(row=2, column=0)
        test6_canv = tk.Canvas(master=self.frm_visual, width=frm_x, height=frm_y, highlightthickness=3, highlightbackground='black')
        test6_canv.grid(row=3, column=0, padx=10, pady=10)
        #-place canvas object
        test6_txt_obj = tk.Label(test6_canv,text=test_text, font=test_font, borderwidth=1, relief="solid", padx=0, pady=0)
        test6_txt = test6_canv.create_window(frm_x/2, frm_y/2, window=test6_txt_obj,anchor=tk.CENTER)
        #test6_pad = self.make_pad_BBOX(test6_canv, test6_txt)


    def make_pad_BBOX(self, prnt_canv, prnt_wgt):
        prntX0, prntY0, prntX1, prntY1 = prnt_canv.bbox(prnt_wgt)           #find the size of the parent widget
        padX0=prntX0-pad_margin; padX1=prntX1+pad_margin                    #calculate X0, x1 for background pad object
        padY0=prntY0; padY1=prntY1                                          #calcualte Y0, Y1 for background pad object
        pad_ref_id = prnt_canv.create_rectangle(padX0, padY0, padX1, padY1) #draw rectangle
        prnt_canv.tag_lower(pad_ref_id, prnt_wgt)                           #place the background pad below the parent widget
    
        return pad_ref_id
    
    def make_pad_ptCONV(self, prnt_canv, prnt_wgt, justify):
        bboxX0, bboxY0, bboxX1, bboxY1 = prnt_canv.bbox(prnt_wgt)   #find the size of the parent widget (just quick/dirty for X coords for now)

        prnt_x0, prnt_y0 = prnt_canv.coords(prnt_wgt)
        prnt_font = prnt_canv.itemcget(prnt_wgt, "font")            #get the font of the parent widget
        prnt_font = re.sub(replace_pattern, 'FONT', prnt_font)      #if font has a space, replace the curly brackets with placeholder for easier split
        prnt_font_parts = prnt_font.split()                         #split the string into parts
        prnt_font_pt = int(prnt_font_parts[1])                      #get the font point

        if justify == tk.NW:
            padX0 = bboxX0-pad_margin; padY0 = bboxY0-pad_margin
            padX1 = bboxX1+pad_margin; padY1 = prnt_y0 + (prnt_font_pt*ppi_pt_conv) + pad_margin
        if justify == tk.CENTER:
            padX0 = bboxX0-pad_margin; padY0 = prnt_y0 - (prnt_font_pt*ppi_pt_conv/2) - pad_margin
            padX1 = bboxX1+pad_margin; padY1 = prnt_y0 + (prnt_font_pt*ppi_pt_conv/2) + pad_margin

        pad_ref_id = prnt_canv.create_rectangle(padX0, padY0, padX1, padY1) #draw rectangle
        prnt_canv.tag_lower(pad_ref_id, prnt_wgt)                           #place the background pad below the parent widget
    
        return pad_ref_id
    
    def make_pad_OVERLAPPING(self, prnt_canv, prnt_wgt):
        #https://stackoverflow.com/questions/63247399/size-coordinates-of-wrapped-text-object-in-tkinter-canvas
        x0, y0, x1, y1 = prnt_canv.bbox(prnt_wgt)   #find the size of the parent widget
        # start of last line
        x = x0
        y = y1 - 1
        # find end x of last line
        while x < x1 and prnt_wgt in prnt_canv.find_overlapping(x, y, x + 1, y + 1):
            x += 1
        # find top y of last line
        while y > y0 and prnt_wgt not in prnt_canv.find_overlapping(x, y, x + 1, y + 1):
            y -= 1
        y += 1
        vertices = [x0, y0, x1, y0, x1, y, x, y, x, y1, x0, y1]
        bg = prnt_canv.create_polygon(*vertices, fill='', outline='black', width=1)
        prnt_canv.tag_lower(bg, prnt_wgt)

#-----------------------------main loop
if __name__ == "__main__":
    app = wndw_Main()
    app.mainloop()